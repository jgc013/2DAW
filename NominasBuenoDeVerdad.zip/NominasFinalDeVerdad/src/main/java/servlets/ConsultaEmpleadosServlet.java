package servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.EmpleadoDAO;
import excepciones.DatosNoCorrectosException;
import model.Empleado;

/**
 * Servlet implementation class ConsultaEmpleadosServlet
 */
@WebServlet("/ConsultaEmpleadosServlet")
public class ConsultaEmpleadosServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConsultaEmpleadosServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		EmpleadoDAO e = new EmpleadoDAO();
		List<Empleado> listaEmpleados;

		try {
			listaEmpleados = e.obtenerEmpleados();
			request.setAttribute("empleados", listaEmpleados);
			RequestDispatcher re = request.getRequestDispatcher("/mostrarEmpleados.jsp");
			re.forward(request, response);
		} catch (SQLException | DatosNoCorrectosException e1) {
			e1.printStackTrace();

		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

}
