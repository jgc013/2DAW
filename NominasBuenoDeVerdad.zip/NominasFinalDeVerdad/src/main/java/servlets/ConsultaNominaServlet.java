package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.nominaDAO;
import excepciones.DatosNoCorrectosException;

/**
 * Servlet implementation class ConsultaNominaServlet
 */
@WebServlet("/ConsultaNominaServlet")
public class ConsultaNominaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConsultaNominaServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String dni = request.getParameter("dni");

		if (dni != null && !dni.isEmpty()) {
			if (!dni.matches("[0-9]{8}[A-Za-z]{1}")) {
				RequestDispatcher re = request.getRequestDispatcher("/buscarSalario.jsp");
				re.forward(request, response);
				return;
			}

			nominaDAO n = new nominaDAO();
			double salario = -1;

			try {
				salario = n.obtenerSalario(dni);

				if (salario > 0) {
					request.setAttribute("salario", salario);
					RequestDispatcher re = request.getRequestDispatcher("/mostrarSalario.jsp");
					re.forward(request, response);
				} else {
					System.out.println("Salario no v�lido");
				}

			} catch (SQLException | DatosNoCorrectosException e) {
				e.printStackTrace();
			}
		} else {
			request.setAttribute("errorDNI", "El DNI no es v�lido");
			System.out.println("DNI no v�lido");
			request.getRequestDispatcher("/buscarSalario.jsp").forward(request, response);
		}

	}

}
