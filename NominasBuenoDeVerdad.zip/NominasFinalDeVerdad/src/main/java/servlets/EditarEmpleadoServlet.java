package servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.EmpleadoDAO;
import excepciones.DatosNoCorrectosException;
import model.Empleado;

/**
 * Servlet implementation class EditarEmpleadoServlet
 */
@WebServlet("/EditarEmpleadoServlet")
public class EditarEmpleadoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditarEmpleadoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String dniB = request.getParameter("dni");
		String opcion = request.getParameter("opcion");
		EmpleadoDAO em = new EmpleadoDAO();

		if (opcion.equals("noEncontrado")) {

			if (!dniB.matches("[0-9]{8}[A-Za-z]{1}")) {
				request.setAttribute("errorDNI", "El DNI no es v�lido");
			}

			if (dniB != null && !dniB.isEmpty() && request.getAttribute("errorDNI") == null) {
				try {
					Empleado empleado = em.obtenerEmpleadoPorDNI(dniB);
					if (empleado != null) {
						request.setAttribute("empleado", empleado);
						request.getRequestDispatcher("editarEmpleado.jsp").forward(request, response);
						return;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

			request.getRequestDispatcher("buscarEmpleado.jsp").forward(request, response);

		} else if (opcion.equals("encontrado")) {

			String dni = request.getParameter("dni");
			String nombre = request.getParameter("nombre");
			String sexo = request.getParameter("sexo");
			int categoria = Integer.parseInt(request.getParameter("categoria"));
			int anyos = Integer.parseInt(request.getParameter("anyos"));

			// Validar DNI
			if (!dni.matches("[0-9]{8}[A-Za-z]{1}")) {
				request.setAttribute("errorDNI", "El DNI no es v�lido");
			}

			// Validar Nombre
			if (nombre.isEmpty()) {
				request.setAttribute("errorNombre", "El nombre no puede estar vac�o");
			}

			// Validar Sexo
			if (!sexo.matches("[MmFf]{1}")) {
				request.setAttribute("errorSexo", "El sexo debe ser M o F");
			}

			// Validar Categor�a
			if (categoria < 1) {
				request.setAttribute("errorCategoria", "La categor�a debe ser mayor a 0");
			}

			// Validar A�os
			if (anyos < 0) {
				request.setAttribute("errorAnyos", "Los a�os deben ser un n�mero positivo");
			}

			// Si hay errores, volver a la p�gina con los mensajes de error
			if (request.getAttribute("errorDNI") != null || request.getAttribute("errorNombre") != null
					|| request.getAttribute("errorSexo") != null || request.getAttribute("errorCategoria") != null
					|| request.getAttribute("errorAnyos") != null) {
				request.getRequestDispatcher("editarEmpleado.jsp").forward(request, response);
				return;
			}

			// Si no hay errores, procesar los datos
			try {
				Empleado empleado = new Empleado(nombre, dni, sexo, categoria, anyos);
				em.editarEmpleadoPorDNI(dni, empleado);

				request.setAttribute("actualizacionExitosa", true);

				// Redirigir de vuelta a la misma p�gina
				request.getRequestDispatcher("buscarEmpleado.jsp").forward(request, response);

			} catch (SQLException | DatosNoCorrectosException e) {
				// Manejar la excepci�n
				e.printStackTrace();
			}

		}

	}

}
